# Pixel 10 で FAP V87.10 を起動

```bash
cd ~
rm -rf FAP_V87_10_PROGRAM_SYNTH
python3 -m zipfile -e /mnt/shared/Download/FAP_V87_10_PROGRAM_SYNTH_RUNTIME.zip .
cd ~/FAP_V87_10_PROGRAM_SYNTH
python3 fap_v87_10_program_synth_gateway.py
```

Chrome: `http://127.0.0.1:11439/`

試験例:

- `Pythonで文章から数字だけ抽出して合計を出すコードを作って`
- `Pythonでテキストファイルの空行を除いて重複行を消し昇順に並べるコードを作って`
- `PythonでJSONファイルから値が数値のキーだけ取り出すコードを作って`

Qwenは使用しません。Gemma4:E2Bも必須ではありません。
