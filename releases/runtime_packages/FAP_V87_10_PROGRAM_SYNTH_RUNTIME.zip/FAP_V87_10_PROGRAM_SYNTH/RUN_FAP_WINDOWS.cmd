@echo off
cd /d "%~dp0"
py -3 fap_v87_10_program_synth_gateway.py
