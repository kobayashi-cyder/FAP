# FAP V87.10 — Program Synthesizer

Current mobile candidate runtime: **V87.10-program-synth**.

V87.10 keeps V78 distilled local chat, V87.07 Specification Compiler, V87.08/09 code generation, and adds a Stage-3 **Program IR** layer.

## New capability

Natural-language coding requests can be compiled into an ordered, allowlisted Program IR and then emitted as verified Python. Examples include:

- extract numbers -> sum;
- split lines -> remove blanks -> deduplicate -> sort;
- JSON object -> numeric-valued keys;
- parameterized occurrence counting;
- parameterized regex extraction;
- replacement, case conversion, head/tail selection and basic statistics.

The generated candidate must pass Python parse/compile, AST policy, deterministic self-test and size checks before artifact promotion.

This is bounded program synthesis, not unrestricted arbitrary-code generation. Unknown operations remain PARTIAL instead of fabricating implementation.
