# FAP V87.10 Program Synthesizer

V87.09のPrimitive合成の上に、自然言語から順序付きProgram IRを生成するStage 3を追加したローカルRuntimeです。

生成経路:

`自然言語 -> CodeSpec -> Program IR -> verified emitter -> compile/policy/self-test -> artifact`

既存のV87.07ゲームBuilder、V78蒸留会話、V87.08/09固定・合成コード生成は維持します。
