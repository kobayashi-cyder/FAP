#!/bin/sh
set -eu
cd "$(dirname "$0")"
exec python3 fap_v87_11_sol_gap_gateway.py
