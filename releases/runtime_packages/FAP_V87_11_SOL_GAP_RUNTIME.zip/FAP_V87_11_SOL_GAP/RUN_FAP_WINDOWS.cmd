@echo off
cd /d "%~dp0"
py -3 fap_v87_11_sol_gap_gateway.py
