# FAP V87.11 Sol-gap — Pixel 10

現在のFAPを Ctrl+C で停止し、ZIPを Android の Download に保存した後:

```bash
cd ~
rm -rf FAP_V87_11_SOL_GAP
python3 -m zipfile -e /mnt/shared/Download/FAP_V87_11_SOL_GAP_RUNTIME.zip .
cd ~/FAP_V87_11_SOL_GAP
python3 fap_v87_11_sol_gap_gateway.py
```

Chrome:

`http://127.0.0.1:11439/`

推奨試験:

1. `今日の日付と12+34を教えて`
2. `目的は単一HTMLのゲームを完成させること。Qwenは使わない。`
3. 何十ターンか後に `今の目的と条件は？`
4. `途中で失敗しても目的を達成するまでどう進める？`
5. `Pythonで文章から数字だけ抽出して合計を出すコードを作って`

`/api/v1/state?session=default` で保持中の目標・条件も確認できます。
