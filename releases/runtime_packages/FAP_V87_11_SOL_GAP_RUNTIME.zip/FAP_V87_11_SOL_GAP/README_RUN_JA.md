# FAP V87.11 Sol-gap Runtime

起動:

```bash
python3 fap_v87_11_sol_gap_gateway.py
```

UI: `http://127.0.0.1:11439/`

V87.10のProgram IR/Builderを維持しつつ、長期状態、複数意図、候補プラン、批評、限定再計画を追加します。
外部LLMは必須ではありません。Qwenは使用しません。
