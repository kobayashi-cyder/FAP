# FAP Latest

Current Pixel candidate runtime: **V87.11-sol-gap**

Adds a local reasoning-controller layer over V87.10:

- 160-turn raw conversation history;
- persistent goal / constraint / explicit-fact ledger;
- multi-intent organ orchestration;
- candidate-plan deliberation;
- coverage critic;
- one bounded replan round;
- explicit knowledge boundary;
- V87.10 Program IR code generation retained;
- external teacher optional; Qwen not used.

This is a harness-level capability improvement, not a claim of GPT-5.6 Sol parity.
