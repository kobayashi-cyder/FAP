# Pixel 10 — FAP V87.09

既存FAPを Ctrl+C で停止し、ZIPを Download に保存後:

```bash
cd ~
rm -rf FAP_V87_09_COMPOSITIONAL_CODEGEN
python3 -m zipfile -e /mnt/shared/Download/FAP_V87_09_COMPOSITIONAL_CODEGEN_RUNTIME.zip .
cd ~/FAP_V87_09_COMPOSITIONAL_CODEGEN
python3 fap_v87_09_compositional_codegen_gateway.py
```

Chrome: `http://127.0.0.1:11439/`

試験例:

- `Pythonで文章の単語数と文字数を数えるツールを作って`
- `Pythonで数字のリストを昇順に並べ替えて重複を消すコードを作って`
- `PythonでJSONファイルを読み込んでキー一覧と値の型を表示するスクリプトを作って`
- `HTMLで入力した文章を逆順にして文字数も表示するツールを作って`

外部LLM不要。Qwen不使用。
