# FAP V87.09 実行

```bash
python3 fap_v87_09_compositional_codegen_gateway.py
```

ブラウザ: `http://127.0.0.1:11439/`

V87.08の固定ターゲットを維持しつつ、V87.09では認識済みPrimitiveを組み合わせたコード合成を追加しています。未知の意味処理は推測でコード化せず、PARTIALとして不足情報を返します。
