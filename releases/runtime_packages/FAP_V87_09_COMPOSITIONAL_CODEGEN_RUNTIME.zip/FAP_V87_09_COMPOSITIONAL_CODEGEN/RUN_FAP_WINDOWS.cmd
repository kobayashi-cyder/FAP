@echo off
cd /d "%~dp0"
py -3 fap_v87_09_compositional_codegen_gateway.py
