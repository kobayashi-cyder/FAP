#!/bin/sh
set -eu
cd "$(dirname "$0")"
exec python3 fap_v87_09_compositional_codegen_gateway.py
