# FAP V87.09 — Compositional Code Generator

V87.09 extends V87.08 from fixed verified targets to bounded primitive composition.

## New

- Natural-language CodeSpec compilation for composable Python and HTML tools.
- Python primitives: word/char/line count, reverse, upper/lower, unique, sort, sum, mean, median, min/max, JSON keys/types.
- HTML primitives: word/char/line count, reverse, upper/lower, optional localStorage.
- Generated candidates still pass compile/static checks and deterministic self-test before artifact promotion.
- Unknown semantics remain PARTIAL instead of fabricated code.
- External LLM is not required. Qwen is not used.

## Boundary

This is bounded compositional synthesis, not unrestricted arbitrary-program generation. Only recognized primitives are composed automatically.
