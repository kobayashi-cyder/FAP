@echo off
cd /d "%~dp0"
py -3 fap_v87_07_spec_compiler_gateway.py
