# FAP latest candidate runtime

- Candidate: **V87.07 Specification Compiler**
- Base: V87.06 Concept-to-Mechanism Builder
- Added: natural-language constraint extraction, structured spec compilation, generic grid-game composer
- Local-first: yes
- External LLM required: no
- Qwen: not used
- Promotion status: candidate runtime; do not treat as mainline until Pixel regression succeeds
