# FAP V87.07 Specification Compiler — Pixel 10

外部LLMなし、Qwenなし。V78蒸留会話 + V87.06 Concept Builder + V87.07 Constraint Extractor / Specification Compiler。

## 起動

```bash
cd ~
rm -rf FAP_V87_07_SPEC_COMPILER
python3 -m zipfile -e /mnt/shared/Download/FAP_V87_07_SPEC_COMPILER_RUNTIME.zip .
cd ~/FAP_V87_07_SPEC_COMPILER
python3 fap_v87_07_spec_compiler_gateway.py
```

Chrome: `http://127.0.0.1:11439/`

## 新しい実機試験

```text
6×6の盤面で緑の駒を上下左右に動かすゲームを作って。
星を5個集めたら勝ち。
3回動くたびに赤い障害物の位置をランダムに変える。
赤い障害物に触れたら負け。
スマホのボタンで操作できて、再スタートもできるようにして。
```

この依頼は再質問せず、`fap_compiled_grid_game.html` を生成するのが合格条件です。
