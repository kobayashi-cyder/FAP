# FAP V87.07 Specification Compiler

V87.07は、未知の制作依頼の文章から明示された制約を構造化し、Specへコンパイルしてローカル合成します。

経路: `builder intent -> constraint extraction -> specification compiler -> mechanism mapping -> primitive composition -> verification -> artifact`

既存のV87.06既知ゲーム/Concept Resolverは保持します。Gemma4:E2Bは必須ではなく、Qwenは使用しません。
