#!/bin/sh
set -eu
cd "$(dirname "$0")"
exec python3 fap_v87_07_spec_compiler_gateway.py
