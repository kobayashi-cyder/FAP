# Pixel 10 — FAP V87.08 Code Generator

V87.08はV87.07を維持したまま、ローカルCode Generatorを追加します。外部LLMは不要です。

起動:

```bash
cd ~/FAP_V87_08_CODE_GENERATOR
python3 fap_v87_08_code_generator_gateway.py
```

Chrome:

```text
http://127.0.0.1:11439/
```

試験例:
- `Pythonで四則演算できる電卓を作って。`
- `CSVを読み込んで平均・中央値・最大値を表示するPythonスクリプトを作って。`
- `HTMLでメモ帳を作って。入力内容をブラウザに保存して。`
- `HTMLでボタンを押すと増えるカウンターを作って。`

生成候補はworkspaceで検証され、合格したファイルだけartifactsへ昇格します。
