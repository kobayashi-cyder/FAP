@echo off
cd /d "%~dp0"
py -3 fap_v87_08_code_generator_gateway.py
