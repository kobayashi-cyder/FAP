#!/bin/sh
set -eu
cd "$(dirname "$0")"
exec python3 fap_v87_08_code_generator_gateway.py
