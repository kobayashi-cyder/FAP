# FAP Latest — V87.08 Code Generator

V87.08 keeps the V87.07 local distilled/specification Builder and adds a constrained local Code Generator Organ.

## Added
- CodeSpec compilation for supported code tasks.
- Python generation: safe calculator and CSV statistics utility.
- HTML generation: localStorage notepad and interactive counter.
- JSON and Markdown artifact generation.
- candidate workspace -> validation -> deterministic self-test -> bounded repair -> artifact promotion.
- Python AST policy rejects dangerous dynamic execution/import paths in generated candidates.
- no Gemma4:E2B dependency; teacher remains optional.
- Qwen is not used.

## Boundary
This is Stage 1 constrained code generation, not arbitrary unrestricted natural-language programming. Unknown Python/HTML requests remain in Code Generator and ask only for missing implementation details rather than fabricating code.
