# FAP V87.08 実行

```bash
python3 fap_v87_08_code_generator_gateway.py
```

主経路:

```text
自然言語 -> Builder Intent -> Code Generator claim -> CodeSpec -> Candidate -> Compile/Static Validation -> Self-Test -> Bounded Repair -> Artifact
```

ゲーム制作はV87.07までのConcept/Specification Builderへそのまま流れます。
