# FAP V87.06 Concept-to-Mechanism Builder

Entrypoint:

```bash
python3 fap_v87_06_concept_builder_gateway.py
```

V87.06はV78蒸留会話脳を維持し、BuilderにConcept Resolverを追加します。外部LLMは必須ではありません。Qwenは使用しません。
