#!/bin/sh
set -eu
cd "$(dirname "$0")"
exec python3 fap_v87_06_concept_builder_gateway.py
