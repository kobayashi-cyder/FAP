# FAP V87.06 Concept-to-Mechanism Builder — Pixel Candidate

V87.06 extends V87.05 with a local Concept Resolver before artifact composition.

- create/build intent remains inside Builder;
- concept name and mechanic descriptions are scored into known mechanisms;
- new local concepts: Minesweeper, 2048, Memory Match;
- Minesweeper can resolve from mechanics without saying the game name;
- 2048 can resolve from mechanics without saying `2048`;
- unknown game requests return a minimal structured question plan instead of falling back to chat;
- artifact generation remains local, single-file, offline, verified before promotion;
- V87.05 Tetris/Breakout/PONG/Snake behavior is retained;
- Gemma4:E2B remains optional, not required;
- Qwen is not used.

Boundary: this is a bounded concept graph + mechanism composer. It does not contain universal world knowledge and does not claim arbitrary programming ability.
