@echo off
cd /d "%~dp0"
py -3 fap_v87_06_concept_builder_gateway.py
pause
