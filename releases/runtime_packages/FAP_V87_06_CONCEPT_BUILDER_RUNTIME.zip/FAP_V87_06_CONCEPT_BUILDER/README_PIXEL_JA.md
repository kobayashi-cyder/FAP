# Pixel 10 — FAP V87.06 Concept Builder

旧FAPを `Ctrl+C` で停止し、ZIPをAndroidのDownloadへ保存してから実行します。

```bash
cd ~
rm -rf FAP_V87_06_CONCEPT_BUILDER
python3 -m zipfile -e /mnt/shared/Download/FAP_V87_06_CONCEPT_BUILDER_RUNTIME.zip .
cd ~/FAP_V87_06_CONCEPT_BUILDER
python3 fap_v87_06_concept_builder_gateway.py
```

Chrome: `http://127.0.0.1:11439/`

推奨試験:
- `マインスイーパーを作成してください。`
- `地雷を避けて、周囲の数字を手掛かりにマスを開け、旗を置くゲームを作って。`
- `2048を作って。`
- `4×4のタイルをスライドして、同じ数字を合体させるゲームを作って。`
- `神経衰弱を作って。`
- `未知のゲームを作って。`（Builder内で必要最小限の質問になること）
