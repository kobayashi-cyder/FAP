# FAP V87.04 Builder Candidate

- Base: V87.03-distilled local-first conversation
- Added: constrained Generic Builder Organ Stage 1
- Added: deterministic Tetris single-HTML recipe
- Added: artifact workspace -> validation -> promotion loop
- Added: goal-aware planning/debugging arbitration
- Gemma4:E2B: optional teacher only
- Qwen: not used
- Status: candidate runtime; not promoted to GitHub mainline yet
