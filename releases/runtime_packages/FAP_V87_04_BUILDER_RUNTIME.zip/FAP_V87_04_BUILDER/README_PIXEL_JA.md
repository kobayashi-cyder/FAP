# FAP V87.04 Builder — Pixel 10

V87.03-distilled にローカル Builder Organ Stage 1 を追加した候補Runtimeです。
Gemma4:E2Bは必須ではありません。Qwenは使用しません。

## 起動

```bash
cd ~
rm -rf FAP_V87_04_BUILDER
python3 -m zipfile -e /mnt/shared/Download/FAP_V87_04_BUILDER_RUNTIME.zip .
cd ~/FAP_V87_04_BUILDER
python3 fap_v87_04_builder_gateway.py
```

Chrome: `http://127.0.0.1:11439/`

## Stage 1 Builder

- `テトリスを作成できますか？` → `fap_tetris.html` を実生成・検証・リンク返却
- HTML/Webページ → オフライン単一HTML候補
- JSON設定ファイル → JSON候補

Builderは `runtime/v87_04/workspace` に候補を作り、検証合格後だけ `runtime/v87_04/artifacts` へ昇格します。
任意自然言語からの無制限コード生成はまだ主張しません。
