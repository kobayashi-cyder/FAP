# FAP V87.04 Builder Candidate Runtime

V87.03-distilled のローカル会話を維持したまま、成果物を実生成する Builder Organ Stage 1 を追加した候補Runtimeです。

## 主な能力

- V78 蒸留回路によるローカル会話（外部LLM必須ではない）
- 日時 / 計算 / 会話記憶 / 検証 / 天気 / 画像ルーティング
- Goal-aware planning/debugging arbitration
- Builder Stage 1
  - テトリス: オフライン単一HTMLを実生成
  - 汎用HTMLページ: オフライン単一HTML
  - JSON設定ファイル
- 候補生成 -> 検証 -> artifacts昇格

## Pixel 10

```bash
cd ~
rm -rf FAP_V87_04_BUILDER
python3 -m zipfile -e /mnt/shared/Download/FAP_V87_04_BUILDER_RUNTIME.zip .
cd ~/FAP_V87_04_BUILDER
python3 fap_v87_04_builder_gateway.py
```

Chrome: `http://127.0.0.1:11439/`

チャットで `テトリスを作成できますか？` と送ると、検証後に `fap_tetris.html` のリンクを返します。

## テスト

```bash
python3 -m unittest discover -s tests -v
```

Gemma4:E2Bは任意の教師で、既定のフォールバックはOFFです。Qwenは使用しません。

## 境界

これは Builder Stage 1 です。任意の自然言語要求から無制限にコードを合成する能力はまだ主張しません。現在は確定レシピと制約付きPrimitiveから成果物を構成します。
