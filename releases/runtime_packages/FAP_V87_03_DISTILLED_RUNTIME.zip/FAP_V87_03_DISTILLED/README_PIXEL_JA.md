# FAP V87.03-distilled — Pixel 10 local runtime

この候補Runtimeは、V87.02 Gatewayの一般会話経路をGemma4:E2B必須から外し、FAP V78のGemma 4 Direct-Learning Integration由来の蒸留状態をローカル第一経路にしたものです。

## 重要

- Pixel 10にGemma4やOllamaを入れる必要はありません。
- Qwenは使用しません。
- `state` は外部教師が無くても `ready` になります。
- Gemma4:E2Bは任意の教師です。既定ではフォールバック自体がOFFです。
- V78は neural-weight transfer ではなく state/circuit distillation です。Gemma 4そのものと同等の一般知識を持つ、という意味ではありません。

## 蒸留状態

- behavior circuits: 10
- teacher shadow memory: 22
- source concept nodes: 28
- source concept edges: 27
- source artifact SHA-256: `e12f51a37681d3aabb4dd00d320fe1bf31362a7e939e454b4e7abc1f7db66909`

## Pixel 10で起動

TerminalでZIPを展開後、フォルダへ移動して:

```bash
chmod +x RUN_FAP_PIXEL.sh
./RUN_FAP_PIXEL.sh
```

または直接:

```bash
python3 fap_v87_03_distilled_gateway.py
```

Chromeで:

```text
http://127.0.0.1:11439/
```

## 確認

「こんにちは」では外部モデルなしでFAP自身が返答します。

「エラーが出て動かない。どう切り分ける？」ではV78 `debugging` 回路が発火します。

「終わるまで自分で考えて進めるには？」ではV78 `planning` 回路が発火します。

未知の事実質問には、知っているふりをせず「現在の蒸留回路だけでは確定回答できない」と返します。

## 任意の教師を使う場合だけ

既定では不要です。有効化したい場合だけ:

```bash
export FAP_TEACHER_FALLBACK=1
export FAP_OLLAMA_BASE=http://<teacher-host>:11434
export FAP_MODEL=gemma4:e2b
./RUN_FAP_PIXEL.sh
```
