# FAP Chat Protocol 1.0 — distilled local runtime

UI remains capability-agnostic.

`POST /api/v1/chat` routes dedicated abilities first (datetime/calculator/weather/image/memory). General chat routes to the local V78 distilled organ. An external teacher is optional and disabled by default.

`GET /api/v1/status` reports `state=ready` when the local distilled brain is loaded, even when `teacher_available=false`.
