#!/bin/sh
set -eu
cd "$(dirname "$0")"
export FAP_HOST="${FAP_HOST:-127.0.0.1}"
export FAP_PORT="${FAP_PORT:-11439}"
# External teacher is OFF by default. V78 distilled local brain is primary.
export FAP_TEACHER_FALLBACK="${FAP_TEACHER_FALLBACK:-0}"
exec python3 fap_v87_03_distilled_gateway.py
