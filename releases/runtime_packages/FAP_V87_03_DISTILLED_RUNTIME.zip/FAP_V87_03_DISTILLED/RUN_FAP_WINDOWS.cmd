@echo off
setlocal
cd /d "%~dp0"
if not defined FAP_HOST set "FAP_HOST=127.0.0.1"
if not defined FAP_PORT set "FAP_PORT=11439"
if not defined FAP_TEACHER_FALLBACK set "FAP_TEACHER_FALLBACK=0"
where py >nul 2>&1 && py -3 fap_v87_03_distilled_gateway.py && exit /b %errorlevel%
python fap_v87_03_distilled_gateway.py
