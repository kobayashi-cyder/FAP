# FAP V87.03-distilled candidate

Local-first Pixel runtime built on V87.02 Gateway and the V78 Gemma 4 Direct-Learning Integration state.

Key change: general chat no longer requires Gemma4:E2B. The V78 distilled behavior circuits and teacher-shadow are the primary local path. External Gemma4:E2B remains an optional teacher only when `FAP_TEACHER_FALLBACK=1`.

This package is a runtime candidate, not a claim that GitHub main has already been promoted beyond V87.02.
