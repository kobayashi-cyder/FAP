# FAP V87.02 実行パッケージ

これは GitHub `kobayashi-cyder/FAP` の current mainline V87.02 を基準にした、会話実行系の持ち出しパッケージです。

## 含まれるもの

- `fap_v87_02_gateway.py` — FAP Core / API / 会話ルータ
- `RUN_FAP_V87_02_WEB.cmd` — Windows起動
- `web/FAP_Chat.html` — PC/Androidブラウザ用UI
- `tests/test_v87_02_gateway.py` — routing回帰テスト
- `docs/FAP_CHAT_PROTOCOL.md` — API境界
- `FAP_LATEST.md` — バージョン情報

## 必須

- Windows + Python 3
- 一般会話を使う場合: Ollama互換API上の `gemma4:e2b`
- AndroidからPC上FAPへ接続する場合: ADB

Qwen依存はありません。

## 起動

1. ZIPを展開
2. `RUN_FAP_V87_02_WEB.cmd` をダブルクリック
3. PC: `http://127.0.0.1:11439/`
4. USB接続Android: runnerが `adb reverse tcp:11439 tcp:11439` を試行
5. Android Chromeでも `http://127.0.0.1:11439/`

## 手動起動

```bat
py -3 fap_v87_02_gateway.py
```

## テスト

```bat
py -3 -m unittest tests.test_v87_02_gateway -v
```

## Gemma4:E2B

既定:
```text
FAP_MODEL=gemma4:e2b
FAP_OLLAMA_BASE=http://127.0.0.1:11434
```

モデルが見つからない場合でも、日時・計算・意図判定などは動きますが一般会話は `degraded` になります。

## 注意

このパッケージは **V87.02 の現在の会話Gateway実行系** です。
V87の自己改善コア（V82/V84/V86依存を含む全リリースツリー）はこの最小実行ZIPには含めていません。
