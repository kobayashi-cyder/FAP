# FAP V87.05 Generic Composition Builder

Entry point: `fap_v87_05_generic_builder_gateway.py`

Architecture:
`create intent -> ArtifactSpec -> feature decomposition -> Primitive registry -> composition -> validation -> artifact`.

The builder is intentionally bounded. It can compose verified local artifacts from known primitives and keeps unknown creation tasks in Builder planning instead of pretending it can generate arbitrary software.
