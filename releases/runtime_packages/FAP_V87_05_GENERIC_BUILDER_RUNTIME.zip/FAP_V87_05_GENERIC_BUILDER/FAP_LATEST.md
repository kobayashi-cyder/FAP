# FAP V87.05 Generic Composition Builder — Pixel Candidate

V87.05 keeps V87.03 distilled local conversation and V87.04 artifact delivery, then expands Builder routing and composition.

- create/build intent no longer falls back to chat merely because the target name is unknown;
- feature/mechanics inference -> Primitive selection -> composition -> validation -> artifact promotion;
- local single-HTML compositions: Tetris, Breakout, PONG, Snake;
- mechanic-first Breakout inference (ball + paddle + bricks) works without relying on the game name;
- unknown create requests remain in Builder as PARTIAL plans with explicit missing requirements;
- Gemma4:E2B remains optional and disabled as a required dependency;
- Qwen is not used.

Boundary: this is a bounded compositional builder, not arbitrary general-purpose natural-language programming.
