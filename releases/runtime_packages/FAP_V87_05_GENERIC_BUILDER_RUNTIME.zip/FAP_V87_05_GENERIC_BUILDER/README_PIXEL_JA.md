# Pixel 10 — FAP V87.05 Generic Builder

1. 旧FAPを Ctrl+C で停止。
2. ZIPをAndroid Downloadへ保存。
3. Terminalで以下を実行。

```bash
cd ~
rm -rf FAP_V87_05_GENERIC_BUILDER
python3 -m zipfile -e /mnt/shared/Download/FAP_V87_05_GENERIC_BUILDER_RUNTIME.zip .
cd ~/FAP_V87_05_GENERIC_BUILDER
python3 fap_v87_05_generic_builder_gateway.py
```

Chrome: `http://127.0.0.1:11439/`

推奨試験:
- `ブロック崩しを作成してください。`
- `ボールをパドルで打ってブロックを消すゲームを作って。`
- `PONGゲームを作って。`
- `スネークゲームを作成して。`
- `未知の装置を作成して。`（chatへ落ちずBuilder PARTIALになること）
