@echo off
cd /d "%~dp0"
py -3 fap_v87_05_generic_builder_gateway.py
pause
